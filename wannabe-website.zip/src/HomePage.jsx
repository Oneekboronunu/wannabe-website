import React from "react";

const HomePage = () => {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", fontWeight: "bold" }}>Wannabe</h1>
        <nav style={{ display: "flex", gap: "1rem" }}>
          <a href="#shop">Shop</a>
          <a href="#about">About</a>
          <a href="#lookbook">Lookbook</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <section style={{ textAlign: "center", marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: "600" }}>Become Who You’re Meant to Be</h2>
        <p style={{ maxWidth: "600px", margin: "1rem auto", color: "#555" }}>
          Streetwear with a purpose. Wannabe isn’t just fashion — it’s a movement.
        </p>
        <button style={{ padding: "0.75rem 2rem", fontSize: "1rem" }}>Shop Now</button>
      </section>

      <section id="shop" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1.5rem", marginBottom: "3rem" }}>
        {["Hoodies", "Tees", "Accessories"].map((item, idx) => (
          <div key={idx} style={{ border: "1px solid #ddd", padding: "1rem", borderRadius: "8px" }}>
            <h3 style={{ fontSize: "1.25rem", fontWeight: "bold" }}>{item}</h3>
            <p style={{ color: "#777", marginBottom: "1rem" }}>Explore our latest {item.toLowerCase()} collection.</p>
            <button>View {item}</button>
          </div>
        ))}
      </section>

      <section id="about" style={{ textAlign: "center", marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>Our Story</h2>
        <p style={{ maxWidth: "800px", margin: "1rem auto", color: "#666" }}>
          Wannabe is a mindset. We started this brand to inspire people to rise, evolve, and express their ambitions through timeless style and self-belief.
        </p>
      </section>

      <section id="lookbook" style={{ textAlign: "center", marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>Lookbook</h2>
        <p style={{ maxWidth: "600px", margin: "1rem auto", color: "#666" }}>
          Dive into our curated aesthetic — a visual expression of the Wannabe movement.
        </p>
        <button>View Lookbook</button>
      </section>

      <section id="contact" style={{ textAlign: "center" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>Contact Us</h2>
        <p style={{ marginBottom: "0.5rem", color: "#666" }}>
          Have questions or need support? Reach out via email or follow us on social media.
        </p>
        <p>Email: support@wannabe.com</p>
      </section>
    </div>
  );
};

export default HomePage;